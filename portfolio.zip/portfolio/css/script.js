$('.skill-per').each(function(){
    var $this = $(this);
    var per = $this.attr('per');
    $this.css("width",per+'%');
    $({animatedValue: 0}).animate({animatedValue: per},{
      duration: 1000,
      step: function(){
        $this.attr('per', Math.floor(this.animatedValue) + '%');
      },
      complete: function(){
        $this.attr('per', Math.floor(this.animatedValue) + '%');
      }
    });
  });

  const button = document.querySelectorAll(".work-list");
  const section = document.querySelectorAll(".thumb");
  button.forEach(item =>{
      item.addEventListener('click',()=>{
          button.forEach(item =>{
              item.className ="";
          });
              item.className ="active";
              //show images
              let values = item.textContent;
              section.forEach(show =>{
                  show.style.display = "none";
                  if(show.getAttribute("data-id")===values || values ==="all"){
                      show.style.display = "block";
                  }
              })
      });
  });            